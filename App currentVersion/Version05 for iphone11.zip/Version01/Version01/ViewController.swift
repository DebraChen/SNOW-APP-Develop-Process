
//  ViewController.swift
//  Version01
//
//  Created by Yuwei Chen on 04/11/2022.
//

import UIKit


class ViewController: UIViewController {
    @IBOutlet weak var MorseCode01: UITextField!
    @IBOutlet weak var MorseButton01: UIButton!
    @IBOutlet weak var MorsecodeImage01: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initialSetup()
    }
 
    
    //cornerRadius and keyboard setup, basic hide keyboard func
    private func initialSetup(){
        MorseCode01.layer.cornerRadius = 2
        MorseButton01.layer.cornerRadius = 4
        MorsecodeImage01.layer.cornerRadius = 2
        
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideKeyboard)))
        
        
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardDidShowNotification, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardDidHideNotification, object: nil)
    }
    
    @objc private func hideKeyboard(){
        self.view.endEditing(true)
    }

//    //keyboard roll up
//    @objc private func keyboardWillShow(notification: NSNotification){
//        if let keyboardFrame: NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey]as? NSValue{
//            let keyboardHeight = keyboardFrame.cgRectValue.height
//            let bottomSpace = self.view.frame.height - (MorseButton01.frame.origin.y + MorseButton01.frame.height)
//            self.view.frame.origin.y -= keyboardHeight - bottomSpace + 40
//        }
//    }
//
//    //Hide
//    @objc private func keyboardWillHide(){
//        self.view.frame.origin.y = 0
//    }
//
//    deinit {
//        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
//        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
//    }
//
    
    //code verify function
    @IBAction func MoveToStory(_ sender: Any) {
        if self.MorseCode01.text! == "05072009"{
            self.performSegue(withIdentifier: "C1Segue", sender: self)
            MorseCode01.text = ""        }else{
                print("404")
                self.performSegue(withIdentifier: "C2Segue", sender: self)
                MorseCode01.text = ""
                //next version add clean the textfield after click the button
            }

    }
}










class ViewController2: UIViewController {
        @IBOutlet weak var MorseCode02: UITextField!
        @IBOutlet weak var MorseButton02: UIButton!
    @IBOutlet weak var MorsecodeImage02: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initialSetup()
    }
    //cornerRadius and keyboard setup, basic hide keyboard func
    private func initialSetup(){
        MorseCode02.layer.cornerRadius = 2
        MorseButton02.layer.cornerRadius = 4
        MorsecodeImage02.layer.cornerRadius = 2
        
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideKeyboard)))
    }
    
    @objc private func hideKeyboard(){
        self.view.endEditing(true)
    }

    @IBAction func MoveToStory2(_ sender: Any) {
        if self.MorseCode02.text! == "2019"{
            self.performSegue(withIdentifier: "C3Segue", sender: self)
            MorseCode02.text = ""        }else{
                print("404")
                self.performSegue(withIdentifier: "C4Segue", sender: self)
                MorseCode02.text = ""
                //next version add clean the textfield after click the button
            }
        
        
    }
}


class ViewController3: UIViewController {
    
    @IBOutlet weak var MorseCode03: UITextField!
    @IBOutlet weak var MorseButton03: UIButton!
    @IBOutlet weak var MorsecodeImage03: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initialSetup()
    }
    
    private func initialSetup(){
        MorseCode03.layer.cornerRadius = 2
        MorseButton03.layer.cornerRadius = 4
        MorsecodeImage03.layer.cornerRadius = 2
        
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideKeyboard)))
    }
    
    @objc private func hideKeyboard(){
        self.view.endEditing(true)
    }
    
    @IBAction func MoveToStory3(_ sender: Any) {
        if self.MorseCode03.text! == "????"{
            self.performSegue(withIdentifier: "C5Segue", sender: self)
            MorseCode03.text = ""        }else{
                print("404")
                self.performSegue(withIdentifier: "C6Segue", sender: self)
                MorseCode03.text = ""
                //next version add clean the textfield after click the button
            }
        
        
    }
}
