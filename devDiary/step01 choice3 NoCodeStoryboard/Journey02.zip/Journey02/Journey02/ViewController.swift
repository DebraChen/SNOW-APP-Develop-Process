//
//  ViewController.swift
//  Journey02
//
//  Created by Yuwei Chen on 28/10/2022.
//

import UIKit

class ViewController: UIViewController {

  
    
    //interact button 01
    @IBAction func Map01(_ sender: Any) {
        //Choice 1
        //Add the next storyboard ID(copy from class) in the specitic page, then call it
     //   let view = self.storyboard?.instantiateViewController(withIdentifier: "Code01Controller")as!Code01Controller
     //   self.present(view, animated: true, completion:nil)
        
        //Choice 2
        //NavigationController2
        let view = self.storyboard?.instantiateViewController(withIdentifier: "Code01Controller")as!Code01Controller
        self.navigationController?.pushViewController(view, animated: true)
        
         }
    



    
    @IBAction func Code01(_ sender: Any) {
        //Choice 1
        //Add the next storyboard ID(copy from class) in the specitic page, then call it
     let view = self.storyboard?.instantiateViewController(withIdentifier: "Code01Controller")as!Code01Controller
        self.present(view, animated: true, completion:nil)
        
        //Choice 2
        //NavigationController2
     //   let view2 = self.storyboard?.instantiateViewController(withIdentifier: "C01_storyTellingController")as!C01_storyTellingController
    //    self.navigationController?.pushViewController(view2, animated: true)
        
         }
    
    
    

   
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    


}

